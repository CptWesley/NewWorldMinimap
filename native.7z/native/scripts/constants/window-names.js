define({
  BACKGROUND: 'background',
  DESKTOP: 'desktop',
  IN_GAME: 'in_game',
  NOTIFICATION: 'notification'
});