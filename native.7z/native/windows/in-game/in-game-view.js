define([
  '../SampleAppView.js'
], function (SampleAppView) {

  class InGameView extends SampleAppView {
    constructor() {
      super();
    }
  }

  return InGameView;
});