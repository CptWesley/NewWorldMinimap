define([

], function () {

  class CloseController {
    static async run() {
    }
  }

  return CloseController;
});
