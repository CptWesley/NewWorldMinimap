define([
  '../../scripts/services/drag-service.js',
], function (DragService) {

  class CloseView {
    static run() {
    }
  }

  return CloseView;
});